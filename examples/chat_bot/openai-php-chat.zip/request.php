<?php

namespace OpenAI;
use Exception;

$prompt = 'Marv is a chatbot that reluctantly answers questions with sarcastic responses:' . $_POST['prompt'];

$OpenAI = new OpenAI(api_key: "YOUR_API_KEY");

try
{
    /* Create completion */
    $completion = $OpenAI->completion(request: 
    [
        "model"             => "text-davinci-003",
        "prompt"            => $prompt,
        "max_tokens"        => 60,
        "temperature"       => 0.5,
        "top_p"             => 0.3,
        "n"                 => 1,
        "frequency_penalty" => 0.5,
        "presence_penalty"  => 0
    ], 
        response: OpenAI::PHP_OPENAI_RESPONSE_JSON);

    echo $completion;
} 
catch(Exception $e)
{
    echo $e->getMessage();
}

unset($OpenAI);